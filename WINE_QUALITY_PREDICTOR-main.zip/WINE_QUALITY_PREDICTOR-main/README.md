# WINE_QUALITY_PREDICTOR
PYTHON, MACHiNE LEARNiNG, DATA ANALYSiS, JUPYTER NOTEBOOKS
• Developed Python machine learning model using Random Forest for accurate wine quality prediction.
• Attained high accuracy of 87% using Random Forest Classifier.
• Analyzed dataset with Pandas, Seaborn, and Matplotlib.
